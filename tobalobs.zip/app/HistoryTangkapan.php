<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HistoryTangkapan extends Model
{
    protected $table = "history_tangkapan";
    public $timestamps = false;
}
